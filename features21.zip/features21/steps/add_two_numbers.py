from behave import given, when, then

@given('the numbers "{num1}" and "{num2}"')
def step_given_two_numbers(context, num1, num2):
    # Convert the numbers to integers and store them in the context
    context.num1 = int(num1)
    context.num2 = int(num2)

@when("the numbers are added")
def step_when_numbers_added(context):
    # Add the two numbers and store the result in the context
    context.result = context.num1 + context.num2

@then('the result should be "{result}"')
def step_then_result_should_be(context, result):
    # Assert that the result matches the expected value
    assert context.result == int(result), f"Expected {result}, but got {context.result}"
