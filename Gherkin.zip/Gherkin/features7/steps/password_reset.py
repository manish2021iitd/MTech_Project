from behave import given, when, then

@given("the user is on the password reset page")
def step_impl(context):
    context.page = "password reset page"

@given("enters their registered email address")
def step_impl(context):
    context.email = "user@example.com"

@when("the user submits the reset request")
def step_impl(context):
    context.reset_link_sent = True

@then("a reset link is sent to their email")
def step_impl(context):
    assert context.reset_link_sent

@then("the user sees a confirmation message")
def step_impl(context):
    context.message = "A reset link has been sent to your email."
    assert context.message == "A reset link has been sent to your email."
