def before_scenario(context, scenario):
    # Initialize an empty cart for each scenario
    context.cart = []
