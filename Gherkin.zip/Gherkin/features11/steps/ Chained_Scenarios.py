#11. Chained Scenarios
from behave import given, when, then

@given("the user is on the product page")
def step_impl(context):
    context.page = "product page"

@when("the user adds a product to the cart")
def step_impl(context):
    context.cart = ["item1"]

@then("the cart should display the added product")
def step_impl(context):
    assert "item1" in context.cart

@given("the user has items in their cart")
def step_impl(context):
    context.cart = ["item1"]  # Initialize the cart with an item
    assert len(context.cart) > 0

@when("the user proceeds to checkout")
def step_impl(context):
    context.page = "checkout page"

@then("the checkout page should display the cart details")
def step_impl(context):
    assert context.page == "checkout page"
    assert "item1" in context.cart
