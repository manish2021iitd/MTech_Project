#Using Background
from behave import given, when, then

@given("the user is logged in")
def step_impl(context):
    context.logged_in = True

@when("the user navigates to the profile page")
def step_impl(context):
    context.page = "profile page"

@then("the user's profile details should be displayed")
def step_impl(context):
    assert context.logged_in
    assert context.page == "profile page"

@when("the user updates their profile information")
def step_impl(context):
    context.profile_updated = True

@then("the changes should be saved successfully")
def step_impl(context):
    assert context.profile_updated
