from behave import given, when, then

@given("the user is on the file upload page")
def step_impl(context):
    context.page = "file upload page"

@when("the user uploads a file with size 5MB")
def step_impl(context):
    context.file_size = 5  # in MB
    context.upload_status = "success" if context.file_size <= 10 else "failed"

@then("the file should be uploaded successfully")
def step_impl(context):
    assert context.upload_status == "success"

@then("a confirmation message should be displayed")
def step_impl(context):
    context.message = "File uploaded successfully"
    assert context.message == "File uploaded successfully"
