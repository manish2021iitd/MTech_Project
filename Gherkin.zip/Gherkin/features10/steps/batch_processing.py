from behave import given, when, then

#Parallel Execution

@given("the user uploads multiple files")
def step_impl(context):
    context.files = ["file1", "file2", "file3"]

@when("the system starts processing")
def step_impl(context):
    context.processing_status = "in-progress"

@then("all files should be processed in parallel")
def step_impl(context):
    context.processing_status = "completed"
    assert context.processing_status == "completed"

@then("the results should be displayed together")
def step_impl(context):
    context.results = ["file1 processed", "file2 processed", "file3 processed"]
    assert len(context.results) == 3
