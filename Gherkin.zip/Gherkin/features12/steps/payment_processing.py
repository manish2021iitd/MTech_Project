from behave import given, when, then

@given("the user is on the payment page")
def step_impl(context):
    context.page = "payment page"

@when("the user enters valid card details")
def step_impl(context):
    context.card_status = "valid"

@then("the payment should be successful")
def step_impl(context):
    assert context.card_status == "valid"

@when("the user enters invalid card details")
def step_impl(context):
    context.card_status = "invalid"

@then('an error message "Payment failed" should be displayed')
def step_impl(context):
    assert context.card_status == "invalid"
    context.error_message = "Payment failed"
    assert context.error_message == "Payment failed"
