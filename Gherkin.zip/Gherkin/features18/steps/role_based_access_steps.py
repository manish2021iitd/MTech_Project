from behave import given, when, then

@given('the user is logged in as "{role}"')
def step_impl(context, role):
    context.role = role

@when("the user navigates to the admin panel")
def step_impl(context):
    if context.role == "Admin":
        context.access_granted = True
    else:
        context.access_granted = False

@then("the user should have access")
def step_impl(context):
    assert context.access_granted

@then('the user should see an "Access Denied" message')
def step_impl(context):
    assert not context.access_granted
    context.message = "Access Denied"
    assert context.message == "Access Denied"
