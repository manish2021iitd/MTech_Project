#Tags for Categorization
from behave import given, when, then

@given("the user is on the product page")
def step_impl(context):
    context.page = "product page"

@when("the user adds an item to the cart")
def step_impl(context):
    context.cart = ["item"]

@then("the item should be displayed in the cart")
def step_impl(context):
    assert "item" in context.cart

@given("an item is in the cart")
def step_impl(context):
    context.cart = ["item"]

@when("the user removes the item")
def step_impl(context):
    context.cart.remove("item")

@then("the cart should be empty")
def step_impl(context):
    assert not context.cart
