#Data Tables
from behave import given, when, then

@given("the user is on the registration page")
def step_impl(context):
    context.page = "registration page"

@when("the user fills in the following details")
def step_impl(context):
    context.details = {row["Field"]: row["Value"] for row in context.table}

@when("submits the form")
def step_impl(context):
    context.registration_status = "success"

@then("the user should see a registration success message")
def step_impl(context):
    assert context.registration_status == "success"
