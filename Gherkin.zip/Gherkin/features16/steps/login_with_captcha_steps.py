from behave import given, when, then

@given("the user is on the login page")
def step_impl(context):
    context.page = "login page"
    context.failed_attempts = 0
    context.captcha_prompt = False

@when("the user enters an incorrect password three times")
def step_impl(context):
    context.failed_attempts += 3
    if context.failed_attempts >= 3:
        context.captcha_prompt = True

@then("the system should prompt for Captcha")
def step_impl(context):
    assert context.captcha_prompt

@then("the login should remain unsuccessful")
def step_impl(context):
    context.login_status = "failed"
    assert context.login_status == "failed"
