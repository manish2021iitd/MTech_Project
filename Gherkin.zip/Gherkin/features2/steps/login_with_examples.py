#Scenario Outline with Examples
from behave import given, when, then

@given("the user is on the login page")
def step_impl(context):
    context.page = "login page"

@when('the user enters "{username}" and "{password}"')
def step_impl(context, username, password):
    context.login_status = "success" if password == "pass1" else "failed"

@then('the login "{status}" should be displayed')
def step_impl(context, status):
    assert context.login_status == status
