from behave import given, when, then

@given("the user is on the login page")
def step_impl(context):
    context.page = "login page"

@when("the user enters valid credentials")
def step_impl(context):
    context.credentials = "valid"

@then("the user is redirected to the dashboard")
def step_impl(context):
    assert context.credentials == "valid"
    context.page = "dashboard"
    assert context.page == "dashboard"
