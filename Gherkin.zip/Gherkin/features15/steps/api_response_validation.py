import json
from behave import given, when, then

@given('the API endpoint "/users/1" is available')
def step_given_api_endpoint(context):
    context.api_endpoint = "/users/1"

@when("a GET request is sent")
def step_when_get_request(context):
    # Simulating a response for demonstration purposes
    context.response_status = 200
    context.response_body = {
        "id": 1,
        "name": "John Doe",
        "email": "john.doe@example.com"
    }

@then("the response status should be 200")
def step_then_response_status(context):
    assert context.response_status == 200, f"Expected 200 but got {context.response_status}"

@then("the response body should contain")
def step_then_response_body(context):
    # Parse the expected response from the feature file
    expected_body = json.loads(context.text)
    assert context.response_body == expected_body, f"Expected {expected_body} but got {context.response_body}"
