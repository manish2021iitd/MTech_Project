from behave import given, when, then

@given('the user has the following tier: "{tier}"')
def step_impl(context, tier):
    context.tier = tier

@when("the user applies a discount code")
def step_impl(context):
    tier_discounts = {"Basic": 5, "Premium": 10, "Platinum": 20}
    context.discount = tier_discounts.get(context.tier, 0)

@then('the discount percentage should be "{discount}%"')
def step_impl(context, discount):
    assert context.discount == int(discount)
