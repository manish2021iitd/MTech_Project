#Multiline Strings

from behave import given, when, then

@given("the user is on the terms and conditions page")
def step_impl(context):
    context.page = "terms page"

@when("the user views the terms text")
def step_impl(context):
    context.terms_text = (
        "These are the terms and conditions.\n"
        "Please read them carefully before using the service."
    )

@then(u'the text should be')
def step_impl(context):
    expected_text = """These are the terms and conditions.
    Please read them carefully before using the service."""
    
    # Simulate fetching the actual text from the page (replace with actual code)
    actual_text = """These are the terms and conditions.
    Please read them carefully before using the service."""
    
    # Check if the actual text matches the expected text
    assert actual_text == expected_text, f"Text validation failed!\nExpected:\n{expected_text}\n\nActual:\n{actual_text}"
