from behave import given, when, then

#Negative Scenarios

@given("the user is on the login page")
def step_impl(context):
    context.page = "login page"

@when("the user enters an invalid username or password")
def step_impl(context):
    context.login_status = "failed"

@then('an error message "Invalid credentials" should be displayed')
def step_impl(context):
    assert context.login_status == "failed"
    context.error_message = "Invalid credentials"
    assert context.error_message == "Invalid credentials"
