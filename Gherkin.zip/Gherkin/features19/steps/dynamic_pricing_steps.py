from behave import given, when, then

@given("the product price is $100")
def step_impl(context):
    context.product_price = 100

@when('the user is located in "{location}"')
def step_impl(context, location):
    if location == "USA":
        context.discount = 10  # in percentage
    else:
        context.discount = 0

@then("a 10% discount should be applied")
def step_impl(context):
    assert context.discount == 10

@then("the final price should be $90")
def step_impl(context):
    final_price = context.product_price - (context.product_price * context.discount / 100)
    assert final_price == 90
