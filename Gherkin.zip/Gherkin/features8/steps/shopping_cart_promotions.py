from behave import given, when, then

@given("the user is logged in")
def step_impl(context):
    context.logged_in = True

@given("the user is a premium member")
def step_impl(context):
    context.premium_member = True

@given("the user is not a premium member")
def step_impl(context):
    context.premium_member = False

@when('the user adds items to the cart')
def step_impl(context):
    # Example of setting a valid cart total for the test
    context.cart_total = 120  # Set a value greater than 100
    print(f"Cart total: {context.cart_total}")

@when("the cart total exceeds $100")
def step_impl(context):
    print(f"Cart total: {context.cart_total}")
    assert context.cart_total > 100

@when('the cart total does not exceed $100')
def step_impl(context):
    context.cart_total = 80  # Set a valid value ≤ 100
    print(f"Cart total: {context.cart_total}")
    assert context.cart_total <= 100


@then("a 10% discount is applied")
def step_impl(context):
    assert context.premium_member and context.cart_total > 100
    context.discount_applied = True

@then("the discount should not be applied")
def step_impl(context):
    assert not (context.premium_member and context.cart_total > 100)
    context.discount_applied = False
