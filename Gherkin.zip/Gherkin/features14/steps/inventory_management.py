from behave import given, when, then

@given("the following products exist in the system")
def step_impl(context):
    # Convert Stock values to integers while creating the dictionary
    context.products = {
        row["Product ID"]: {
            "Product ID": row["Product ID"],
            "Name": row["Name"],
            "Stock": int(row["Stock"])
        }
        for row in context.table
    }

@when("the stock levels are updated")
def step_impl(context):
    for product_id, product in context.products.items():
        product["Stock"] += 10  # Update stock levels

@then("the system should reflect the changes correctly")
def step_impl(context):
    for product in context.products.values():
        assert product["Stock"] > 0, f"Stock level is invalid for {product['Name']}"
