from behave import given, when, then

@given("the user is logged in")
def step_impl(context):
    context.logged_in = True
    context.notification_count = 0

@when("a new message is received")
def step_impl(context):
    if context.logged_in:
        context.notification_count += 1
        context.notification_message = "You have a new message"

@then("the notification count should increase by 1")
def step_impl(context):
    assert context.notification_count == 1

@then('the notification message should be "You have a new message"')
def step_impl(context):
    assert context.notification_message == "You have a new message"
