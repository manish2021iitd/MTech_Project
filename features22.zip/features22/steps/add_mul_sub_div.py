from behave import given, when, then

class Calculator:
    def __init__(self):
        self.result = None
        self.current_value = None
        self.operation = None

    def enter_number(self, number):
        if self.current_value is None:
            self.current_value = number
        else:
            if self.operation == "add":
                self.result = self.current_value + number
            elif self.operation == "subtract":
                self.result = self.current_value - number
            elif self.operation == "multiply":
                self.result = self.current_value * number
            elif self.operation == "divide":
                if number == 0:
                    self.result = "Division by zero"
                else:
                    self.result = self.current_value / number

    def set_operation(self, operation):
        self.operation = operation


# Create a shared calculator object for the steps
calculator = Calculator()


@given('I have entered {number:d} into the calculator')
def step_enter_number(context, number):
    calculator.enter_number(number)


@when('I press {operation}')
def step_set_operation(context, operation):
    calculator.set_operation(operation)


@when('I have entered {number:d} into the calculator')
def step_enter_second_number(context, number):
    calculator.enter_number(number)


@then('the result should be {expected_result:g} on the screen')
def step_check_result(context, expected_result):
    assert calculator.result == expected_result, f"Expected {expected_result}, but got {calculator.result}"


@then('I should see an error message "{expected_message}"')
def step_check_error_message(context, expected_message):
    assert calculator.result == expected_message, f"Expected message '{expected_message}', but got '{calculator.result}'"
